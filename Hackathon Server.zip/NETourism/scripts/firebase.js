   // Initialize Firebase
var config = {
    apiKey: "AIzaSyD5OM6TZ9NaTtRrEtGrlJudsxClFi4sDfk",
    authDomain: "ne-tourism.firebaseapp.com",
    databaseURL: "https://ne-tourism.firebaseio.com",
    projectId: "ne-tourism",
    storageBucket: "ne-tourism.appspot.com",
    messagingSenderId: "40378564979"
  };
  firebase.initializeApp(config);

var BASE_URL = 'https://netourism5.000webhostapp.com/NETourism/';
var STORAGE_URL = 'https://firebasestorage.googleapis.com/v0/b/ne-tourism.appspot.com/o/';
var WEB_TITLE = 'NE Tourism Server';