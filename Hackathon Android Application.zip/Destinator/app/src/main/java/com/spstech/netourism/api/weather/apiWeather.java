package com.spstech.netourism.api.weather;

import com.spstech.netourism.weather.WeatherResponse;
import com.spstech.netourism.weather.WeatherResponseCurrent;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by saranga on 12/07/2018.
 */

public interface apiWeather {
    @GET("forecast/daily")
    Call<WeatherResponse> getFiveDayWeather(@Query("lat") String lat, @Query("lon") String lon, @Query("mode") String mode, @Query("appid") String appid, @Query("units") String units);
    @GET("weather")
    Call<WeatherResponseCurrent> getCurrentWeather(@Query("lat") String lat, @Query("lon") String lon, @Query("mode") String mode, @Query("appid") String appid, @Query("units") String units);


}
