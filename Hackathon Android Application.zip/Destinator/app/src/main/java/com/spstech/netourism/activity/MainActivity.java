package com.spstech.netourism.activity;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.spstech.netourism.R;
import com.spstech.netourism.activity.AboutActivity;
import com.spstech.netourism.api.weather.apiWeather;
import com.spstech.netourism.api.weather.weatherClient;
import com.spstech.netourism.adapters.SpecialAdapter;
import com.spstech.netourism.model.CategoryModel;
import com.spstech.netourism.maps.online.ActivityMaps;
import com.spstech.netourism.maps.online.MapsOnlineFragment;
import com.spstech.netourism.fragments.AllPlacesCategoryFragment;
import com.spstech.netourism.fragments.AllPlacesFragment;
import com.spstech.netourism.fragments.FilterFragment;
import com.spstech.netourism.fragments.StatesFragment;

import com.spstech.netourism.fragments.SpecialFragment;
import com.spstech.netourism.fragments.UserGalleryFragment;
import com.spstech.netourism.fragments.UserRateFragment;
import com.spstech.netourism.utilities.AppController;
import com.spstech.netourism.config.Config;
import com.spstech.netourism.utilities.Constants;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.security.acl.Group;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import butterknife.Bind;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;
import com.spstech.netourism.weather.WeatherResponse;
import com.spstech.netourism.weather.WeatherResponseCurrent;

/**
 * Created by saranga on 06/07/2018.
 */

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, LocationListener {
    String[] days = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    //private String[]
    private ImageView weather_widget_image_view_icon;
    private ImageView weather_widget_image_view_day_1;
    private ImageView weather_widget_image_view_day_2;
    private ImageView weather_widget_image_view_day_3;
    private ImageView weather_widget_image_view_day_4;
    private ImageView weather_widget_image_view_day_5;
    private ImageView weather_widget_image_view_maker;

    private TextView weather_widget_text_view_city;
    private TextView weather_widget_text_view_temp;
    private TextView weather_widget_text_view_main;

    private TextView weather_widget_text_view_day_1;
    private TextView weather_widget_text_view_day_3;
    private TextView weather_widget_text_view_day_2;
    private TextView weather_widget_text_view_day_4;
    private TextView weather_widget_text_view_day_5;

    private TextView weather_widget_text_view_max_day_5;
    private TextView weather_widget_text_view_max_day_4;
    private TextView weather_widget_text_view_min_day_5;
    private TextView weather_widget_text_view_min_day_4;
    private TextView weather_widget_text_view_max_day_3;
    private TextView weather_widget_text_view_min_day_3;
    private TextView weather_widget_text_view_min_day_1;
    private TextView weather_widget_text_view_max_day_2;
    private TextView weather_widget_text_view_max_day_1;
    private TextView weather_widget_text_view_min_day_2;
    private CardView card_view_weather;
    private LinearLayout linearlayout_bottom;

    private static final String BACK_STACK_ROOT_TAG = "root_fragment";
    private static final String TAG = "MainActivity:";

    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 0; // 5 meters
    private static final long MIN_TIME_BW_UPDATES = 10000; // 1 minute
    private static final int RP_ACCESS_LOCATION = 1;
    private static final String SELECTED_ITEM_ID = "SELECTED_ITEM_ID";
    private final Handler mDrawerHandler = new Handler();

    boolean enable_ads_banner;
    private  static  Spinner spinner;

    @Bind(R.id.toolbar)
    Toolbar toolbar;

    @Bind(R.id.nav_view)
    NavigationView navigationView;
    @Bind(R.id.drawer_layout)
    DrawerLayout drawer;
    @Bind(R.id.adView)
    AdView mAdView;

    View hView;
    TextView uDisplayName;
    ImageView uPhoto;
    Button nav_logout;
    Fragment navFragment = null;

    private LocationManager mLocationManager;
    private boolean isGPSEnabled = false;
    private boolean isNetworkEnabled = false;
    private Location mLocation;
    private String mCurrentLocation = "0.0,0.0";
    private int mPrevSelectedId;
    private int mSelectedId;
    private FirebaseAuth mFAuth = FirebaseAuth.getInstance();
    private FirebaseDatabase mFDatabase = FirebaseDatabase.getInstance();
    private FirebaseUser mFUser;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    private double lat;
    private double lng;

    List<CategoryModel> mCategoryModelList;
    CategoryModel category;
    private static ArrayList<String> categoriesName = new ArrayList<String>();

    private  static ArrayList<String> categoriesId = new ArrayList<String>();

    SpecialAdapter mCategoryAdapter;
    private static String currentState=null;
    private static String spinnerSelectedId=null;
    public static boolean firstLaunch=true;

    void loadConfig() {
        DatabaseReference configRef = mFDatabase.getReference("config").child("ads_config").child(Constants.ENABLE_ADS_BANNER);
        configRef.keepSynced(true);
        configRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    enable_ads_banner = dataSnapshot.getValue(Boolean.class);
                } else {
                    enable_ads_banner = false;
                }

                loadAds(enable_ads_banner);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Config.showToast(drawer, "Database Error!");
            }
        });
    }

    void loadAds(boolean enableThis) {
        if (enableThis) {

            mAdView.setVisibility(View.GONE);

            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    mAdView.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdOpened() {
                    mAdView.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdFailedToLoad(int i) {
                    mAdView.setVisibility(View.GONE);
                }

                @Override
                public void onAdClosed() {
                    mAdView.setVisibility(View.GONE);
                }
            });

            AdRequest adRequest = new AdRequest
                    .Builder()
                    //.addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                    .build();

            mAdView.loadAd(adRequest);
        } else {
            mAdView.setVisibility(View.GONE);
        }

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        ButterKnife.bind(this);
        mCategoryModelList = new ArrayList<>();
        loadCategoryList();
        mCategoryAdapter = new SpecialAdapter(MainActivity.this, mCategoryModelList, mCurrentLocation);

        setSupportActionBar(toolbar);
        loadConfig();
        initView();
        initAction();
        getLocation();
        findLocation();

        hView = navigationView.getHeaderView(0);
        uDisplayName = hView.findViewById(R.id.uDisplayName);
        uPhoto = hView.findViewById(R.id.imageView);
        nav_logout= findViewById(R.id.nav_logout);


        SignFirst();

        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this,
                drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                super.onDrawerSlide(drawerView, 0);
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, 0);
            }
        };
        drawer.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        mSelectedId = navigationView.getMenu().getItem(prefs.getInt("default_view", 0)).getItemId();
        mSelectedId = savedInstanceState == null ? mSelectedId : savedInstanceState.getInt(SELECTED_ITEM_ID);
        mPrevSelectedId = mSelectedId;
        navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

        if (savedInstanceState == null) {
            mDrawerHandler.removeCallbacksAndMessages(null);
            mDrawerHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if(spinner.getVisibility()==View.GONE)
                    {
                        spinner.setVisibility(View.VISIBLE);

                    }
                    navigate(mSelectedId);
                }
            }, getResources().getInteger(R.integer.anim_duration_long));

            boolean openDrawer = prefs.getBoolean("open_drawer", false);

            if (openDrawer)
                drawer.openDrawer(GravityCompat.START);
            else
                drawer.closeDrawers();
        }

        if (savedInstanceState == null) {
            MenuItem item = navigationView.getMenu().findItem(R.id.nav_allplace).setChecked(true);
            onNavigationItemSelected(item);
        }

        getSupportFragmentManager().addOnBackStackChangedListener
                (new FragmentManager.OnBackStackChangedListener() {
                    @Override
                    public void onBackStackChanged() {
                        Fragment f = getSupportFragmentManager().findFragmentById(R.id.container_body);
                        if (f != null) {

                            Log.d("onbackstack", f.getClass().getName());
                            String name = f.getClass().getName();
                            if (name != null) {
                                changeTitle(name);
                            }
                        }
                    }
                });


    }

    void changeTitle(String name) {
        if(name.equals(AllPlacesFragment.class.getName())){
            Log.e("firstlaunch " ,""+firstLaunch);
            setTitle(getString(R.string.nav_title_nearby_place));
            if (firstLaunch==false && spinner.getVisibility()==View.GONE){
                Log.e("firstlaunchu " ,""+firstLaunch);
                spinner.setVisibility(View.VISIBLE);
            }
            firstLaunch=false;



        }
        if(name.equals(FilterFragment.class.getName())){
            spinner.setVisibility(View.VISIBLE);
            toolbar.setTitle("State");
        }

        if(name.equals(SpecialFragment.class.getName())){
            spinner.setVisibility(View.GONE);
            toolbar.setTitle("Special");

        }

        if(name.equals(MapsOnlineFragment.class.getName())){
            spinner.setVisibility(View.GONE);
            toolbar.setTitle("Online Map");

        }

        if(name.equals(UserGalleryFragment.class.getName())){
            spinner.setVisibility(View.GONE);
            toolbar.setTitle("Gallery");

        }
        if(name.equals(UserRateFragment.class.getName())){
            spinner.setVisibility(View.GONE);
            toolbar.setTitle("Rating & Reviews");

        }


    }

    void SignFirst() {

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                mFUser = firebaseAuth.getCurrentUser();
                if (mFUser != null) {
                    String url, displayName;

                    if (mFUser.isAnonymous()) {
                        url = "https://firebasestorage.googleapis.com/v0/b/" + Constants.FIREBASE_PROJECT_ID + ".appspot.com/o/anonymous.png?alt=media";
                        displayName = "Guest";
                        //nav_logout.setText("Sign In");
                    } else {
                        url = String.valueOf(mFUser.getPhotoUrl());
                        displayName = mFUser.getDisplayName();

                        DatabaseReference mDatabase = mFDatabase.getReference("users");

                        SimpleDateFormat formatD = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                        formatD.setTimeZone(TimeZone.getTimeZone("UTC"));
                        String timeStamp = formatD.format(new Date());
                        PostUser post = new PostUser(displayName,
                                String.valueOf(url), timeStamp, mFAuth.getCurrentUser().getEmail(), getIntent().getStringExtra("prov"));
                        Map<String, Object> postValues = post.toMap();
                        Map<String, Object> childUpdates = new HashMap<>();
                        childUpdates.put(mFUser.getUid(), postValues);
                        mDatabase.updateChildren(childUpdates);
                    }

                    uDisplayName.setText(displayName);
                    Glide.with(getApplicationContext())
                            .load(url)
                            .asBitmap()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .centerCrop()
                            .into(new BitmapImageViewTarget(uPhoto) {
                                @Override
                                protected void setResource(Bitmap resource) {
                                    RoundedBitmapDrawable rounded =
                                            RoundedBitmapDrawableFactory.create(MainActivity.this.getResources(), resource);
                                    rounded.setCircular(true);
                                    uPhoto.setImageDrawable(rounded);
                                }
                            });
                } else {
                    MainActivity.this.finish();
                }
            }
        };
    }

    public void getLocation() {
        mLocationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        isGPSEnabled = mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled = mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (!isGPSEnabled && !isNetworkEnabled) {
            Config.showSettingsAlert(MainActivity.this);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) &&
                        ActivityCompat.shouldShowRequestPermissionRationale(this,
                                Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    String[] perm = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    ActivityCompat.requestPermissions(this, perm,
                            RP_ACCESS_LOCATION);
                } else {
                    String[] perm = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    ActivityCompat.requestPermissions(this, perm,
                            RP_ACCESS_LOCATION);
                }
            } else {
                if (isNetworkEnabled) {
                    mLocationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    if (mLocationManager != null) {
                        mLocation = mLocationManager
                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        if (mLocation != null) {
                            onLocationChanged(mLocation);
                        }
                    }
                }

                if (isGPSEnabled) {
                    if (mLocation == null) {
                        mLocationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                        if (mLocationManager != null) {
                            mLocation = mLocationManager
                                    .getLastKnownLocation(LocationManager.GPS_PROVIDER);
                            if (mLocation != null) {
                                onLocationChanged(mLocation);
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        lat = location.getLatitude();
        lng = location.getLongitude();
        mCurrentLocation = lat + "," + lng;
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
        Config.showToast(drawer, getString(R.string.enable_provider) + provider);
    }

    @Override
    public void onProviderDisabled(String provider) {
        Config.showToast(drawer, getString(R.string.disable_provider) + provider);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case RP_ACCESS_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    this.recreate();
                }
        }
    }

    private void navigate(final int itemId) {
        final Bundle bundle = new Bundle();
        bundle.putString("mCurrentLocation", mCurrentLocation);
        switch (itemId) {

            case R.id.nav_allplace:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.nav_title_nearby_place));

                navFragment = new AllPlacesFragment();
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;

            case 11:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.nav_title_nearby_place));


                bundle.putString("category", spinnerSelectedId);

                navFragment = new AllPlacesCategoryFragment();
                navFragment.setArguments(bundle);

                break;
            case 22:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.nav_title_nearby_place));
                spinner.setVisibility(View.VISIBLE);
                spinner.setSelection(0);

                bundle.putString("state", currentState);
                bundle.putString("category", spinnerSelectedId);

                navFragment = new FilterFragment();
                navFragment.setArguments(bundle);

                break;

            case 33:
                mPrevSelectedId = itemId;
                spinner.setVisibility(View.VISIBLE);
                spinner.setSelection(0);
                bundle.putString("state",currentState);
                navFragment = new StatesFragment();
                navFragment.setArguments(bundle);

                break;
            case R.id.assam:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.assam));
                spinner.setVisibility(View.VISIBLE);
                spinner.setSelection(0);
                bundle.putString("state","assam");
                currentState=getString(R.string.assam).toLowerCase();
                navFragment = new StatesFragment();
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.arunachal_pradesh:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.arunachal_pradesh));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.arunachal_pradesh).toLowerCase();
                navFragment = new StatesFragment();
                bundle.putString("state","arunachal pradesh");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.manipur:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.manipur));
                spinner.setVisibility(View.VISIBLE);
                spinner.setSelection(0);
                currentState=getString(R.string.manipur).toLowerCase();

                navFragment = new StatesFragment();
                bundle.putString("state","manipur");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.meghalaya:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.meghalaya));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.meghalaya).toLowerCase();

                navFragment = new StatesFragment();
                bundle.putString("state","meghalaya");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.mizoram:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.mizoram));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.mizoram).toLowerCase();

                navFragment = new StatesFragment();
                bundle.putString("state","mizoram");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.nagaland:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.nagaland));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.nagaland).toLowerCase();

                navFragment = new StatesFragment();
                bundle.putString("state","nagaland");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.sikkim:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.sikkim));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.sikkim).toLowerCase();

                navFragment = new StatesFragment();
                bundle.putString("state","sikkim");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.tripura:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.tripura));
                spinner.setSelection(0);
                spinner.setVisibility(View.VISIBLE);
                currentState=getString(R.string.tripura).toLowerCase();

                currentState=getString(R.string.tripura);
                navFragment = new StatesFragment();
                bundle.putString("state","tripura");
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;

            case R.id.nav_special:
                mPrevSelectedId = itemId;
                setTitle(getString(R.string.nav_title_special));
                spinner.setVisibility(View.GONE);
                navFragment = new SpecialFragment();
                navFragment.setArguments(bundle);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);


                break;
            case R.id.nav_map:
                mPrevSelectedId = itemId;
                if (Config.checkConnection(MainActivity.this)) {
                    setTitle(getString(R.string.nav_title_online_map));
                    spinner.setVisibility(View.GONE);
                    navFragment = new MapsOnlineFragment();
                    navFragment.setArguments(bundle);
                } else {
                    Snackbar snackbar = Snackbar
                            .make(drawer, "Your internet is not connected!", Snackbar.LENGTH_INDEFINITE);
                    snackbar.setAction("FORCE", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            setTitle(getString(R.string.nav_title_online_map));
                            navFragment = new MapsOnlineFragment();
                            navFragment.setArguments(bundle);
                        }
                    });
                    snackbar.show();
                }
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);

                break;
            case R.id.nearby_em:
                mPrevSelectedId = itemId;
                if (Config.checkConnection(MainActivity.this)) {
                    setTitle("NearBy Emergency Places");
                    Intent intent = new Intent(this, ActivityMaps.class);
                    startActivity(intent);
                } else {
                    Snackbar snackbar = Snackbar
                            .make(drawer, "Your internet is not connected!", Snackbar.LENGTH_INDEFINITE);


                    snackbar.show();
                }


                break;
            case R.id.nav_review:
                if (mFUser.isAnonymous()) {
                    Config.alertLoginAnon(MainActivity.this, getString(R.string.alert_anon_temporary));
                } else {
                    mPrevSelectedId = itemId;
                    setTitle(getString(R.string.nav_title_rates_and_reviews));
                    spinner.setVisibility(View.GONE);

                    navFragment = new UserRateFragment();
                    bundle.putString("userID", mFUser.getUid());
                    navFragment.setArguments(bundle);
                    navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);
                }
                break;
            case R.id.nav_gallery:
                if (mFUser.isAnonymous()) {
                    Config.alertLoginAnon(MainActivity.this, getString(R.string.alert_anon_temporary));
                } else {
                    mPrevSelectedId = itemId;
                    setTitle(getString(R.string.nav_title_gallery));
                    spinner.setVisibility(View.GONE);

                    navFragment = new UserGalleryFragment();
                    bundle.putString("userID", mFUser.getUid());
                    navFragment.setArguments(bundle);
                    navigationView.getMenu().findItem(mPrevSelectedId).setChecked(true);
                }
                break;
            case R.id.nav_logout:
                if (mAuthStateListener != null) {
                    if (mFUser != null) {

                        if (mFUser.isAnonymous()) {
                            mFUser.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    FirebaseAuth.getInstance().signOut() ;

                                    mFAuth.removeAuthStateListener(mAuthStateListener);
                                    Intent i=new Intent(MainActivity.this, SignInActivity.class);
                                    startActivity(i);

                                }
                            });


//                            MainActivity.this.finish();
                        } else {
                            FirebaseAuth.getInstance().signOut();
                            mFAuth.removeAuthStateListener(mAuthStateListener);
                            Intent i=new Intent(MainActivity.this, SignInActivity.class);
                            startActivity(i);


                            //                          MainActivity.this.finish();

                        }

                    }
                }
                break;
            case R.id.nav_about:
                mPrevSelectedId = itemId;
                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(false);
                break;
            case R.id.nav_tourOperators:
                mPrevSelectedId = itemId;
                new DownloadActivity().execute(getString(R.string.TourOperatorLink));
                if(DownloadActivity.downloaded==true){
                    File file = new File(Environment.getExternalStorageDirectory(),
                            DownloadActivity.folder+DownloadActivity.fileName);

                    Uri path = Uri.fromFile(file);
                    Intent pdfOpenintent = new Intent(Intent.ACTION_VIEW);
                    pdfOpenintent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    pdfOpenintent.setDataAndType(path, "application/pdf");

                    try {
                        startActivity(pdfOpenintent);
                    }
                    catch (ActivityNotFoundException e) {

                    }
                }
                navigationView.getMenu().findItem(mPrevSelectedId).setChecked(false);
                break;

        }

        if (navFragment != null) {

            String backStackName = navFragment.getClass().getName();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
            try {
                transaction.replace(R.id.container_body, navFragment,"target_tag").addToBackStack(backStackName).commit();
            } catch (IllegalStateException ignored) {
                Log.e(Constants.TAG_PARENT, TAG + ignored.getMessage());
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppController.getApplication(this).registerOttoBus(this);
        getLocation();

    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {

        FragmentManager fragmentManager=getSupportFragmentManager();
        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
            fragmentManager.popBackStack();/*
            Fragment fm=getSupportFragmentManager().findFragmentByTag("target_tag");
            if(fm instanceof AllPlacesFragment){
                spinner.setVisibility(View.VISIBLE);
                toolbar.setTitle(R.string.nav_title_nearby_place);
            }
            if(fm instanceof SpecialFragment){
                spinner.setVisibility(View.INVISIBLE);
                toolbar.setTitle(R.string.nav_title_categories);
            }
            if(fm instanceof FilterFragment){
                spinner.setVisibility(View.VISIBLE);
                toolbar.setTitle("State");
            }*/
        } else if (!doubleBackToExitPressedOnce) {
            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Press BACK again to exit.", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        } else if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (mFUser != null) {
                if (mFUser.isAnonymous()) {
                    mFUser.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            FirebaseAuth.getInstance().signOut();
                            mFAuth.removeAuthStateListener(mAuthStateListener);
                        }
                    });
                }
            }
            super.onBackPressed();
            finish();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mFAuth.addAuthStateListener(mAuthStateListener);
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mLocationManager.removeUpdates(this);
        AppController.getApplication(this).unregisterOttoBus(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        mSelectedId = item.getItemId();
        mDrawerHandler.removeCallbacksAndMessages(null);
        mDrawerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                navigate(mSelectedId);
            }
        }, getResources().getInteger(R.integer.anim_duration_long));

        drawer.closeDrawers();
        return true;

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SELECTED_ITEM_ID, mSelectedId);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mFUser != null) {
            if (mFUser.isAnonymous()) {
                mFUser.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        FirebaseAuth.getInstance().signOut();
                        mFAuth.removeAuthStateListener(mAuthStateListener);
                    }
                });
            }
        }
    }

    @IgnoreExtraProperties
    private class PostUser {
        String displayName;
        String photoUrl;
        String lastAccess;
        String email;
        String providers;

        PostUser() {
            // Default constructor required for calls to DataSnapshot.getValue(Post.class)
        }

        PostUser(String display_name, String photo_url, String last_access, String email, String provider) {
            this.displayName = display_name;
            this.photoUrl = photo_url;
            this.lastAccess = last_access;
            this.email = email;
            this.providers = provider;
        }

        @Exclude
        Map<String, Object> toMap() {
            HashMap<String, Object> result = new HashMap<>();
            result.put("displayName", displayName);
            result.put("photoUrl", photoUrl);
            result.put("email", email);
            result.put("provider", providers);
            result.put("lastAccess", lastAccess);
            return result;
        }
    }

    public void getWeatherFiveDay(String longitude, String latitude, String units) {
        Retrofit retrofit = weatherClient.getClient();
        apiWeather service = retrofit.create(apiWeather.class);
        retrofit2.Call<WeatherResponse> call = service.getFiveDayWeather(latitude, longitude, "json", Config.KEY_APP_WEATHER, units);
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getCod().equals("200")) {
                        setWeatherFiveDay(response.body());
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                // Toast.makeText(getApplicationContext(),t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getCurrentWeather(String longitude, String latitude, String units) {
        Retrofit retrofit = weatherClient.getClient();
        apiWeather service = retrofit.create(apiWeather.class);
        retrofit2.Call<WeatherResponseCurrent> call = service.getCurrentWeather(latitude, longitude, "json", Config.KEY_APP_WEATHER, units);
        call.enqueue(new Callback<WeatherResponseCurrent>() {
            @Override
            public void onResponse(Call<WeatherResponseCurrent> call, Response<WeatherResponseCurrent> response) {
                if (response.isSuccessful()) {
                    if (response.body().getCod().equals("200")) {
                        setsetWeatherCurrent(response.body());
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherResponseCurrent> call, Throwable t) {
                // Toast.makeText(getApplicationContext(),t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void setsetWeatherCurrent(WeatherResponseCurrent weatherResponseCurrent) {
        String units = "°C";

        this.weather_widget_text_view_city.setText(weatherResponseCurrent.getName());
        this.weather_widget_image_view_icon.setImageResource((weatherResponseCurrent.getWeather().get(0).getIconLocal()));

        this.weather_widget_text_view_temp.setText(weatherResponseCurrent.getMain().getTemp() + units);
        this.weather_widget_text_view_main.setText(weatherResponseCurrent.getWeather().get(0).getMain());

    }

    public void findLocation() {
        card_view_weather.setVisibility(View.VISIBLE);
        String latitude = "";
        String longitude ="";

        String units = "metric";
        latitude=mLocation.getLatitude()+"";
        longitude=mLocation.getLongitude()+"";
        getCurrentWeather(longitude,latitude, units);
        getWeatherFiveDay(longitude, latitude, units);
    }

    public void setWeatherFiveDay(WeatherResponse weather) {


        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();

        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Integer DAY_1 = calendar.get(Calendar.DAY_OF_WEEK);
        weather_widget_image_view_day_1.setImageResource(weather.getList().get(1).getWeather().get(0).getIconLocal());
        weather_widget_text_view_day_1.setText(days[DAY_1 - 1]);
        weather_widget_text_view_max_day_1.setText(weather.getList().get(1).getTemp().getMax() + '°');
        weather_widget_text_view_min_day_1.setText(weather.getList().get(1).getTemp().getMin() + '°');

        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Integer DAY_2 = calendar.get(Calendar.DAY_OF_WEEK);
        weather_widget_image_view_day_2.setImageResource(weather.getList().get(2).getWeather().get(0).getIconLocal());
        weather_widget_text_view_day_2.setText(days[DAY_2 - 1]);
        weather_widget_text_view_max_day_2.setText(weather.getList().get(2).getTemp().getMax() + '°');
        weather_widget_text_view_min_day_2.setText(weather.getList().get(2).getTemp().getMin() + '°');

        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Integer DAY_3 = calendar.get(Calendar.DAY_OF_WEEK);
        weather_widget_image_view_day_3.setImageResource(weather.getList().get(3).getWeather().get(0).getIconLocal());
        weather_widget_text_view_day_3.setText(days[DAY_3 - 1]);
        weather_widget_text_view_max_day_3.setText(weather.getList().get(3).getTemp().getMax() + '°');
        weather_widget_text_view_min_day_3.setText(weather.getList().get(3).getTemp().getMin() + '°');

        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Integer DAY_4 = calendar.get(Calendar.DAY_OF_WEEK);
        weather_widget_image_view_day_4.setImageResource(weather.getList().get(4).getWeather().get(0).getIconLocal());
        weather_widget_text_view_day_4.setText(days[DAY_4 - 1]);
        weather_widget_text_view_max_day_4.setText(weather.getList().get(4).getTemp().getMax() + '°');
        weather_widget_text_view_min_day_4.setText(weather.getList().get(4).getTemp().getMin() + '°');


        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Integer DAY_5 = calendar.get(Calendar.DAY_OF_WEEK);
        weather_widget_image_view_day_5.setImageResource(weather.getList().get(5).getWeather().get(0).getIconLocal());
        weather_widget_text_view_day_5.setText(days[DAY_5 - 1]);
        weather_widget_text_view_max_day_5.setText(weather.getList().get(5).getTemp().getMax() + '°');
        weather_widget_text_view_min_day_5.setText(weather.getList().get(5).getTemp().getMin() + '°');
    }

    public void initView() {
        //setContentView(R.layout.main_activity);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        this.weather_widget_image_view_icon = findViewById(R.id.weather_widget_image_view_icon);
        this.weather_widget_image_view_day_1 = findViewById(R.id.weather_widget_image_view_day_1);
        this.weather_widget_image_view_day_2 = findViewById(R.id.weather_widget_image_view_day_2);
        this.weather_widget_image_view_day_3 = findViewById(R.id.weather_widget_image_view_day_3);
        this.weather_widget_image_view_day_4 = findViewById(R.id.weather_widget_image_view_day_4);
        this.weather_widget_image_view_day_5 = findViewById(R.id.weather_widget_image_view_day_5);
        this.weather_widget_image_view_maker = findViewById(R.id.weather_widget_image_view_maker);

        this.weather_widget_text_view_city = findViewById(R.id.weather_widget_text_view_city);
        this.weather_widget_text_view_temp = findViewById(R.id.weather_widget_text_view_temp);
        this.weather_widget_text_view_main = findViewById(R.id.weather_widget_text_view_main);

        this.weather_widget_text_view_day_1 = findViewById(R.id.weather_widget_text_view_day_1);
        this.weather_widget_text_view_day_2 = findViewById(R.id.weather_widget_text_view_day_2);
        this.weather_widget_text_view_day_3 = findViewById(R.id.weather_widget_text_view_day_3);
        this.weather_widget_text_view_day_4 = findViewById(R.id.weather_widget_text_view_day_4);
        this.weather_widget_text_view_day_5 = findViewById(R.id.weather_widget_text_view_day_5);

        this.weather_widget_text_view_max_day_5 = findViewById(R.id.weather_widget_text_view_max_day_5);
        this.weather_widget_text_view_min_day_5 = findViewById(R.id.weather_widget_text_view_min_day_5);
        this.weather_widget_text_view_max_day_4 = findViewById(R.id.weather_widget_text_view_max_day_4);
        this.weather_widget_text_view_min_day_4 = findViewById(R.id.weather_widget_text_view_min_day_4);
        this.weather_widget_text_view_max_day_3 = findViewById(R.id.weather_widget_text_view_max_day_3);
        this.weather_widget_text_view_min_day_3 = findViewById(R.id.weather_widget_text_view_min_day_3);
        this.weather_widget_text_view_max_day_2 = findViewById(R.id.weather_widget_text_view_max_day_2);
        this.weather_widget_text_view_min_day_2 = findViewById(R.id.weather_widget_text_view_min_day_2);
        this.weather_widget_text_view_max_day_1 = findViewById(R.id.weather_widget_text_view_max_day_1);
        this.weather_widget_text_view_min_day_1 = findViewById(R.id.weather_widget_text_view_min_day_1);


        this.linearlayout_bottom = findViewById(R.id.linearlayout_bottom);
        this.card_view_weather = findViewById(R.id.card_view_weather);

    }

    public void initAction() {


        this.weather_widget_image_view_maker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                } else {
                    if (!isGPSEnabled) {
                        Config.showSettingsAlert(MainActivity.this);
                    }
                    findLocation();
                }


            }
        });
        card_view_weather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (linearlayout_bottom.getVisibility() == View.GONE) {
                    linearlayout_bottom.animate()
                            .translationY(0).alpha(1.0f)
                            .setListener(new AnimatorListenerAdapter() {
                                @Override
                                public void onAnimationStart(Animator animation) {
                                    super.onAnimationStart(animation);
                                    linearlayout_bottom.setVisibility(View.VISIBLE);
                                    linearlayout_bottom.setAlpha(0.0f);
                                }
                            });
                } else {
                    linearlayout_bottom.animate()
                            .translationY(0).alpha(0.0f)
                            .setListener(new AnimatorListenerAdapter() {
                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    super.onAnimationEnd(animation);
                                    linearlayout_bottom.setVisibility(View.GONE);
                                }
                            });
                }
            }
        });


    }

    void loadCategoryList(){
        DatabaseReference dRef = mFDatabase.getReference("categories");
        dRef.keepSynced(true);
        dRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Log.e("Count " ,""+dataSnapshot.getChildrenCount());
                mCategoryModelList.clear();
                for(DataSnapshot snap : dataSnapshot.getChildren()){
                    CategoryModel model = snap.getValue(CategoryModel.class);
                    model.setCategoryId(snap.getKey());
                    mCategoryModelList.add(model);
                }

                categoriesName.clear();
                categoriesName.add("ALL Places");
                for(int i=0;i<mCategoryModelList.size();i++){
                    CategoryModel category= mCategoryModelList.get(i);
                    categoriesName.add(category.getCategoryName());
                    categoriesId.add(category.getCategoryId());

                }
                spinner= findViewById(R.id.spinner);
                ArrayAdapter<String> myAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,categoriesName);
                myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(myAdapter);
                spinner.setVisibility(View.VISIBLE);

                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if(currentState==null ) {
                            if(spinner.getSelectedItemPosition()==0){
                                navigate(R.id.nav_allplace);
                                spinner.setVisibility(View.VISIBLE);
                            }else{
                                sortCategoryListByName();
                                setTitle(getString(R.string.nav_title_nearby_place));
                                String catid=categoriesId.get(position-1);
                                spinnerSelectedId=catid;

                                navigate(11);
                            } }
                        else {
                            if (spinner.getSelectedItemPosition() == 0) {
                                navigate(33);



                            } else {
                                sortCategoryListByName();
                                mCategoryAdapter.notifyDataSetChanged();
                                setTitle(currentState);
                                String catid = categoriesId.get(position - 1);
                                spinnerSelectedId = catid;

                                navigate(22);
                            }

                        }

                        final Bundle bundle = new Bundle();
                        //spinnerSelectedId=spinner.getSelectedItem().toString();



                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });


                mCategoryAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(Constants.TAG_PARENT, databaseError.getMessage());
            }
        });

    }

    private void sortCategoryListByName() {

        Collections.sort(mCategoryModelList, new Comparator<CategoryModel>() {
            public int compare(CategoryModel o1, CategoryModel o2) {
                return o1.getCategoryName().compareTo(o2.getCategoryName());
            }
        });
    }
}