package com.spstech.netourism.model;

/**
 * Created by saranga on 13/03/2018.
 */
public class CategoryModel {
    String categoryId;
    String extrasId;

    String categoryName;
    String extrasName;

    String iconFileName;

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setExtrasId(String extrasId) {
        this.extrasId = extrasId;
    }

    public void setExtrasName(String extrasName) {
        this.extrasName = extrasName;
    }

    public void setIconFileName(String iconFileName) {
        this.iconFileName = iconFileName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getExtrasId() {
        return extrasId;
    }

    public String getExtrasName() {
        return extrasName;
    }

    public String getIconFileName() {
        return iconFileName;
    }
}
